#!/bin/bash
DIR="`dirname \"$0\"`"

echo "Start installing cm7-tomcat-installation at /opt/coremedia/cm7-tomcat-installation"

$DIR/INSTALL/preinstall.sh 1

if ! test -d /opt/coremedia/cm7-tomcat-installation; then
  mkdir -p /opt/coremedia/cm7-tomcat-installation
fi

cp -r $DIR/* /opt/coremedia/cm7-tomcat-installation/
chown -R coremedia:coremedia /opt/coremedia/cm7-tomcat-installation

echo "You can now delete this directory. To uninstall call the uninstall.sh script at /opt/coremedia/cm7-tomcat-installation"
