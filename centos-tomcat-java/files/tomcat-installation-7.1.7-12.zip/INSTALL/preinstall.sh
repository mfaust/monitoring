#!/bin/sh
if [ $1 -eq 1 ] ; then
  # initial installation

  # configure environment
  if test -d /opt/coremedia; then
    find /opt/coremedia -xdev | xargs chown coremedia:coremedia
  else
     mkdir -p /opt/coremedia
  fi

  # Add the "coremedia" user, on Solaris you should replace /usr/sbin/nologin with /usr/bin/false
  /usr/sbin/useradd -c "system user to run coremedia services and applications" -s /bin/bash -m -d /opt/coremedia -r coremedia 2> /dev/null || :
fi
