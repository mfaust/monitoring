#!/bin/bash
DIR="`dirname \"$0\"`"

if [ "$1" != "-y" ]; then
  while true
  do
    read -p "uninstall cm7-tomcat-installation now (y/n) ? " answer
    case $answer in
     [yY]* )
             break;;

     [nN]* ) exit;;

     * )     echo "Enter Y or N.";;
    esac
  done
fi

echo "Start uninstalling cm7-tomcat-installation from /opt/coremedia/cm7-tomcat-installation"
if [ -d /opt/coremedia/cm7-tomcat-installation ]; then
 rm -rf /opt/coremedia/cm7-tomcat-installation
fi
